﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class DialogueScript : MonoBehaviour
{
    //Variables
    [Header("Components")]public ManagerScript manager;

    [Header("UI Elements")]
    public GameObject dialogueUI;
    public TextMeshProUGUI dialogueText;
    public TextMeshProUGUI dialogueName;
    public Image dialoguePortrait;

    public int currentLineNo;
    public int totalLines;
    public bool isConversing;
    public ConversationScript currentConversation;

    private bool isTyping;
    private int counter;
    public int largeNumber = 10000;

    private void Start()
    {
        currentLineNo = -10;
    }

    //Functions
    public void DialogueBehaviour(ConversationScript currentConvo)  //Called EVERY FRAME.
    {
        print(isTyping);

        if (Input.GetKeyDown(KeyCode.I) && currentConversation != null)
        {
            if (currentLineNo < 0 && !isTyping) { StartConversation(); StartCoroutine(TypeWriter()); }
            else if (currentLineNo >= 0 && currentLineNo < totalLines-1 && !isTyping) { ProgressConversation(); StartCoroutine(TypeWriter()); }
            else if (currentLineNo >= totalLines-1 && !isTyping) { EndConversation(); }

            else if (isTyping) { counter = largeNumber; }
        }

        if (currentLineNo >= 0) { dialogueText.text = currentConvo.myLines[currentLineNo].myText; }
    }


    public void StartConversation()
    {
        dialogueUI.SetActive(true);
        currentLineNo = 0;
        totalLines = currentConversation.myLines.Length;
    }

    public void ProgressConversation()
    {
        StopAllCoroutines();
        if (Input.GetKeyDown(KeyCode.I))
        {
            currentLineNo += 1;
        }
    }
    
    public void EndConversation()
    {
        StopAllCoroutines();
        dialogueUI.SetActive(false);
        currentLineNo = -10;
    }
    
    IEnumerator TypeWriter()
    {
        counter = 0;

        isTyping = true;

        while (true)
        {
            /*#region
            print("counter value:      " + counter);
            print("Visible characters: " + dialogueText.maxVisibleCharacters);
            print("full text length:   " + dialogueText.text.Length);
            print("is typing:          " + isTyping);
            #endregion*/

            dialogueText.maxVisibleCharacters = counter;

            if (dialogueText.maxVisibleCharacters >= dialogueText.text.Length) { isTyping = false; }


            counter += 1;

            yield return new WaitForSeconds(0.05f);
        }
    }
}
