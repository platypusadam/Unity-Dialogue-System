﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagerScript : MonoBehaviour
{



    //Variables
    [Header("Components")] 
    public DialogueScript dScript;

    [Header("List of Conversations in this Scene:")]
    public ConversationScript[] conversations;

    [HideInInspector]
    public bool isTalking = false;



    private void Update()
    {
        //Decide on a conversation to display
        if (Input.GetKeyDown(KeyCode.Alpha1)) { dScript.currentConversation = conversations[0]; isTalking = false; }
        else if (Input.GetKeyDown(KeyCode.Alpha2)) { dScript.currentConversation = conversations[1]; isTalking = false; }

        dScript.DialogueBehaviour(dScript.currentConversation);
    }
}
