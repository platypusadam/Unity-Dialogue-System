﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Line", menuName = "Dialogue Line")]
public class LineScript : ScriptableObject
{
    public string myName;
    [TextArea(4, 8)] public string myText;
    public Sprite mySprite;
}
