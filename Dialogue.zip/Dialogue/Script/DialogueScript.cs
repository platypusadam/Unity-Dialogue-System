﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
//using UnityEditorInternal;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class DialogueScript : MonoBehaviour
{
    //Variables
    [Header("Components")] 
    public ManagerScript manager;
    public GameObject player;

    [Header("UI Elements")]
    public GameObject dialogueUI;
    public TextMeshProUGUI dialogueText;
    public TextMeshProUGUI dialogueName;
    public Image dialoguePortrait;
    private bool mFaded;
    public float fadeDuration = 0.2f;

    [HideInInspector] public int currentLineNo;
    [HideInInspector] public int totalLines;
    [HideInInspector] public bool isConversing;
    [HideInInspector] public ConversationScript currentConversation;
    [HideInInspector] public int largeNumber = 10000;
    public AudioSource continueSFX;

    private bool isTyping;
    private int counter;
    

    private void Start()
    {
        mFaded = true;
        print("start");
        currentLineNo = -10;
    }

    //Functions
    public void DialogueBehaviour(ConversationScript currentConvo)  //Called EVERY FRAME.
    {
        if (currentConversation != null)
        {
            if (Input.GetKeyDown(KeyCode.I))
            {
                //Decide whether to start, progress, or end the conversation.
                if (currentLineNo < 0 && !isTyping) { StartConversation(); StartCoroutine(TypeWriter()); }

                //Continue deciding whether to start, progress, or end the conversation.
                else if (currentLineNo >= 0 && currentLineNo < totalLines - 1 && !isTyping) { ProgressConversation(); }
                else if (currentLineNo >= totalLines - 1 && !isTyping) { EndConversation(); }

                
                //Don't touch or it will break. Don't know what it does, though...
                else if (isTyping) { counter = largeNumber; }

                if (currentLineNo >= 0)
                {
                    dialogueText.text = currentConvo.myLines[currentLineNo].myText;
                    dialogueName.text = currentConvo.myLines[currentLineNo].myName;
                    dialoguePortrait.sprite = currentConvo.myLines[currentLineNo].mySprite;
                }
            }
        }
        

    }


    public void StartConversation()
    {
        StopAllCoroutines();
        player.GetComponent<PlayerScript>().canMove = false;
        currentLineNo = 0;
        counter = 0;
        totalLines = currentConversation.myLines.Length;
        LeanTween.alphaCanvas(dialogueUI.GetComponent<CanvasGroup>(), 1, 0.3f);
        if (dialogueUI.GetComponent<CanvasGroup>().alpha == 1)
        {
            dialogueUI.GetComponent<CanvasGroup>().interactable = true;
            StartCoroutine(TypeWriter());
        }
        continueSFX.Play();
    }

    public void ProgressConversation()
    {
        if (isTyping == false && currentConversation.myLines[currentLineNo].hasEvent == true)
        {
            player.GetComponent<cutsceneEvents>().cutSceneEvents[currentConversation.myLines[currentLineNo].CutsceneEventNumber].Invoke();
        }
        currentLineNo += 1;
        StopAllCoroutines();
        StartCoroutine(TypeWriter());
        continueSFX.Play();
    }

    public void EndConversation()
    {
        if (isTyping == false && currentConversation.myLines[currentLineNo].hasEvent == true)
        {
            player.GetComponent<cutsceneEvents>().cutSceneEvents[currentConversation.myLines[currentLineNo].CutsceneEventNumber].Invoke();
        }
        StopAllCoroutines();
        LeanTween.alphaCanvas(dialogueUI.GetComponent<CanvasGroup>(), 0, 0.25f);
        dialogueUI.GetComponent<CanvasGroup>().interactable = false;
        currentLineNo = -10;
        counter = 0;
        player.GetComponent<PlayerScript>().canMove = true;
    }

    IEnumerator TypeWriter()
    {
        counter = 0;

        isTyping = true;

        while (true)
        {
            /*#region
            print("counter value:      " + counter);
            print("Visible characters: " + dialogueText.maxVisibleCharacters);
            print("full text length:   " + dialogueText.text.Length);
            print("is typing:          " + isTyping);
            #endregion*/

            dialogueText.maxVisibleCharacters = counter;

            if (dialogueText.maxVisibleCharacters >= dialogueText.text.Length) { isTyping = false; }


            counter += 1;

            yield return new WaitForSeconds(0.02f);
        }
    }
}
