﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagerScript : MonoBehaviour
{



    //Variables
    [Header("Components")] 
    public DialogueScript dScript;
    public GameObject player;

    [Header("NPCs: (Match the order of Conversation Array Below)")]
    public GameObject NPC0;
    public GameObject NPC1;

    [Header("List of Conversations in this Scene: (Match the order of NPCs above)")]
    public ConversationScript[] conversations;

    [HideInInspector]
    public bool isTalking = false;



    private void Update()
    {
        dScript.DialogueBehaviour(dScript.currentConversation);
        DecideConversation(player);
    }

    public void DecideConversation(GameObject Player)
    {
        if (Player.GetComponent<BoxCollider2D>().IsTouching(NPC0.GetComponent<BoxCollider2D>()))
        {
            dScript.currentConversation = conversations[0];
        }
        else if (Player.GetComponent<BoxCollider2D>().IsTouching(NPC1.GetComponent<BoxCollider2D>()))
        {
            dScript.currentConversation = conversations[1];
        }
        else { dScript.currentConversation = null; }
    }
}
